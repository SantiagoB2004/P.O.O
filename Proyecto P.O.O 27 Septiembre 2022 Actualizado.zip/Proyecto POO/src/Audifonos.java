/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class Audifonos {
    
    private String referencia;
    private String marca;
    private String color;
    private String tipo;
    private String duracionBateria;
    private String calidadSonido;

    public Audifonos(String referencia, String marca, String color, String tipo, String duracionBateria, String calidadSonido) {
        this.referencia = referencia;
        this.marca = marca;
        this.color = color;
        this.tipo = tipo;
        this.duracionBateria = duracionBateria;
        this.calidadSonido = calidadSonido;
    }

    public String getReferencia() {
        return referencia;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getTipo() {
        return tipo;
    }

    public String getDuracionBateria() {
        return duracionBateria;
    }

    public String getCalidadSonido() {
        return calidadSonido;
    }  
}