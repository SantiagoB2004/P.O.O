/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pago;

/**
 *
 * @author 123
 */
public class MetodosPago extends Pago {

    public MetodosPago(String metodo1, String metodo2, String metodo3) {
        super(metodo1, metodo2, metodo3);
    }

    public String getMetodo1() {
        return metodo1;
    }

    public String getMetodo2() {
        return metodo2;
    }

    public String getMetodo3() {
        return metodo3;
    }   
}

