/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pago;

/**
 *
 * @author 123
 */
public abstract class Pago {
    protected String metodo1;
    protected String metodo2;
    protected String metodo3;

    public Pago(String metodo1, String metodo2, String metodo3) {
        this.metodo1 = metodo1;
        this.metodo2 = metodo2;
        this.metodo3 = metodo3;
    }
}
