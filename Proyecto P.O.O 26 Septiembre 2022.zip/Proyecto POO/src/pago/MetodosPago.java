/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pago;

/**
 *
 * @author 123
 */
public class MetodosPago extends Pago {
    
    public MetodosPago(String efectivo, String tarjeta) {
        super(efectivo, tarjeta);
    }

    public String getMetodo1() {
        return metodo1;
    }

    public String getMetodo2() {
        return metodo2;
    }  
}

