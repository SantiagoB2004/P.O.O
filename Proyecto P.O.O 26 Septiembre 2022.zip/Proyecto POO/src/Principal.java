
import javax.swing.JOptionPane;
import pago.*;

/**
 *
 * @author SALA
 */
public class Principal {
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Difinicion objetos celulares
        Celulares objetoCelulares1 = new Celulares ("iPhone 14 pro max \n","Dorado \n", "iPhone \n", "512 GB \n", "16 pixeles \n", "50 pixeles \n");
        Celulares objetoCelulares2 = new Celulares ("Samsung S22 Ultra \n","Negro \n", "Samsung \n", "512 GB \n", "50 pixeles \n", "120 pixeles \n");
        
        //Definicion objetos computadores
        Computadores objetoComputadores1 = new Computadores ("Mac Book pro \n", "Apple \n", "Gris Metalico \n", "No tiene \n", "16 \n", "8 \n");
        Computadores objetoComputadores2 = new Computadores ("HP Pavilion \n","HP \n", "Negro Mate \n", "NVIDIA GEFORCE rtx 4090 \n", "16 \n","16 \n");
        
        //Definicion objetos audifonos
        Audifonos objetoAudifonos1 = new Audifonos ("AirPods Segunda Generacion", "Apple", "Blancos", "Inalambricos", "3", "5-21");
        Audifonos objetoAudifonos2 = new Audifonos ("Galaxy Buds", "Samsung", "Grises", "Inalambricos", "6", "110" ); 
        
        //Definicion objeto menu inicial
        MenuInicial objetoMenuInicial = new MenuInicial("1. Celulares \n","2. Computadores \n","3. Audifonos \n");
        
        //Definicion objeto metodos de pago
        MetodosPago objetoMetodosPago = new MetodosPago("1. Efectivo \n","2. Tarjeta debito o credito \n");
        
        //Saludo
        JOptionPane.showMessageDialog(null,"Buen dia, por favor selecione la opcion deseada:");
        
        //Muestra del menu inicial
        int elec1 = Integer.parseInt(JOptionPane.showInputDialog(null, objetoMenuInicial.getOpcion1()+objetoMenuInicial.getOpcion2()+objetoMenuInicial.getOpcion3()));
        
        //Operaciones segun la opcion escogida
        if (elec1==1){
            int elec11 = Integer.parseInt(JOptionPane.showInputDialog(null,"Contamos con dos opciones de celulares: 1. IPhone        2. Samsung"));
                if (elec11==1){
                    JOptionPane.showMessageDialog(null,"Las especificaciones son: \n"+"Referencia: \n"+objetoCelulares1.getReferencia()+"Color:"+objetoCelulares1.getColor()+"Marca: \n"+objetoCelulares1.getMarca()+"Memoria: \n"+objetoCelulares1.getMemoria()+"Pixeles camara frontal: \n"+objetoCelulares1.getPixelesFrontal()+"Pixeles camara trasera: \n"+objetoCelulares1.getPixelesTrasera());
                    int elec111 = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea comprarlo?  1.Si      2.No"));
                        if (elec111==1){
                            int pago1 = Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el metodo de pago: \n"+objetoMetodosPago.getMetodo1()+objetoMetodosPago.getMetodo2()));
                            if (pago1==1){
                                JOptionPane.showMessageDialog(null,"Dirijase a la caja y pague $6.830.000");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                                }
                            if (pago1==2){
                                JOptionPane.showMessageDialog(null,"Dirijase a las pantallas y pague en cualquiera de los datafonos $6.850.000, por pago con tarjeta se cobran $20.000 mas.");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                            }  
                        }
                        if (elec111==2){
                            JOptionPane.showMessageDialog(null,"Si desea consultar otras opciones, inicie el programa nuevamente, gracias.");
                        }
                    }
                
                if (elec11==2){
                    JOptionPane.showMessageDialog(null,"Las especificaciones son: \n"+"Referencia: \n"+objetoCelulares2.getReferencia()+"Color:"+objetoCelulares2.getColor()+"Marca: \n"+objetoCelulares2.getMarca()+"Memoria: \n"+objetoCelulares2.getMemoria()+"Pixeles camara frontal: \n"+objetoCelulares2.getPixelesFrontal()+"Pixeles camara trasera: \n"+objetoCelulares2.getPixelesTrasera());
                    int elec111 = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea comprarlo?  1.Si      2.No"));
                        if (elec111==1){
                            int pago2 = Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el metodo de pago: \n"+objetoMetodosPago.getMetodo1()+objetoMetodosPago.getMetodo2()));
                            if (pago2==1){
                                JOptionPane.showMessageDialog(null,"Dirijase a la caja y pague $6.150.000");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                                }
                            if (pago2==2){
                                JOptionPane.showMessageDialog(null,"Dirijase a las pantallas y pague en cualquiera de los datafonos $6.170.000, por pago con tarjeta se cobran $20.000 mas.");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                            }  
                        }
                        if (elec111==2){
                            JOptionPane.showMessageDialog(null,"Si desea consultar otras opciones, inicie el programa nuevamente, gracias.");
                        }
                    }     
        }
                
        if (elec1==2){
            int elec21 = Integer.parseInt(JOptionPane.showInputDialog(null,"Contamos con dos opciones de computadores: 1. MacBook       2. HP"));
                if (elec21==1){
                    JOptionPane.showMessageDialog(null,"Las especificaciones son: \n"+"Referencia: \n"+objetoComputadores1.getReferencia()+"Marca: \n"+objetoComputadores1.getMarca()+"Color: \n"+objetoComputadores1.getColor()+"Tarjeta Grafica: \n"+objetoComputadores1.getTarjetaGrafica()+"Pulgadas: \n"+objetoComputadores1.getPulgadas()+"Memoria RAM: \n"+objetoComputadores1.getRam());
                    int elec211 = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea comprarlo?  1.Si      2.No"));
                        if (elec211==1){
                            int pago3 = Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el metodo de pago: \n"+objetoMetodosPago.getMetodo1()+objetoMetodosPago.getMetodo2()));
                            if (pago3==1){
                                JOptionPane.showMessageDialog(null,"Dirijase a la caja y pague $6.200.000");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                                }
                            if (pago3==2){
                                JOptionPane.showMessageDialog(null,"Dirijase a las pantallas y pague en cualquiera de los datafonos $6.220.000, por pago con tarjeta se cobran $20.000 mas.");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                            }    
                        }
                        
                        if (elec211==2){
                            JOptionPane.showMessageDialog(null,"Si desea consultar otras opciones, inicie el programa nuevamente, gracias.");
                        }
                    }
                
                if (elec21==2){
                    JOptionPane.showMessageDialog(null,"Las especificaciones son: \n"+"Referencia: \n"+objetoComputadores2.getReferencia()+"Marca: \n"+objetoComputadores2.getMarca()+"Color: \n"+objetoComputadores2.getColor()+"Tarjeta Grafica: \n"+objetoComputadores2.getTarjetaGrafica()+"Pulgadas: \n"+objetoComputadores2.getPulgadas()+"Memoria RAM: \n"+objetoComputadores2.getRam());
                    int elec221 = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea comprarlo?  1.Si      2.No"));
                        if (elec221==1){
                            int pago4 = Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el metodo de pago: \n"+objetoMetodosPago.getMetodo1()+objetoMetodosPago.getMetodo2()));
                        if (pago4==1){
                            JOptionPane.showMessageDialog(null,"Dirijase a la caja y pague $1.080.000");
                            JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                                }
                        if (pago4==2){
                            JOptionPane.showMessageDialog(null,"Dirijase a las pantallas y pague en cualquiera de los datafonos $1.100.000, por pago con tarjeta se cobran $20.000 mas.");
                            JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                            }    
                        }
                        if (elec221==2){
                            JOptionPane.showMessageDialog(null,"Si desea consultar otras opciones, inicie el programa nuevamente, gracias.");
                        }
        }
                
                }
        
        if (elec1==3){
            int elec31 = Integer.parseInt(JOptionPane.showInputDialog(null,"Contamos con dos opciones de celulares: 1. Apple        2. Samsung"));
                if (elec31==1){
                    JOptionPane.showMessageDialog(null,"Las especificaciones son: \n"+"Referencia: \n"+objetoAudifonos1.getReferencia()+"Marca: \n"+objetoAudifonos1.getMarca()+"Color: \n"+objetoAudifonos1.getColor()+"Tipo: \n"+objetoAudifonos1.getTipo()+"Duracion bateria en horas: \n"+objetoAudifonos1.getDuracionBateria()+"Calidad sonido en Hz: \n"+objetoAudifonos1.getCalidadSonido());
                    int elec311 = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea comprarlo?  1.Si      2.No"));
                        if (elec311==1){
                            int pago5 = Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el metodo de pago: \n"+objetoMetodosPago.getMetodo1()+objetoMetodosPago.getMetodo2()));
                            if (pago5==1){
                                JOptionPane.showMessageDialog(null,"Dirijase a la caja y pague $700.000");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                                }
                            if (pago5==2){
                                JOptionPane.showMessageDialog(null,"Dirijase a las pantallas y pague en cualquiera de los datafonos $720.000, por pago con tarjeta se cobran $20.000 mas.");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                            }
                        }
                        if (elec311==2){
                            JOptionPane.showMessageDialog(null,"Si desea consultar otras opciones, inicie el programa nuevamente, gracias.");
                        }
                    }
                
                if (elec31==2){ 
                    JOptionPane.showMessageDialog(null,"Las especificaciones son: \n"+"Referencia: \n"+objetoAudifonos2.getReferencia()+"Marca: \n"+objetoAudifonos2.getMarca()+"Color: \n"+objetoAudifonos2.getColor()+"Tipo: \n"+objetoAudifonos2.getTipo()+"Duracion bateria en horas: \n"+objetoAudifonos2.getDuracionBateria()+"Calidad sonido en Hz: \n"+objetoAudifonos2.getCalidadSonido());
                    int elec311 = Integer.parseInt(JOptionPane.showInputDialog(null,"Desea comprarlo?  1.Si      2.No"));
                        if (elec311==1){
                            int pago6 = Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el metodo de pago: \n"+objetoMetodosPago.getMetodo1()+objetoMetodosPago.getMetodo2()));
                            if (pago6==1){
                                JOptionPane.showMessageDialog(null,"Dirijase a la caja y pague $400.000");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                                }
                            if (pago6==2){
                                JOptionPane.showMessageDialog(null,"Dirijase a las pantallas y pague en cualquiera de los datafonos $420.000, por pago con tarjeta se cobran $20.000 mas.");
                                JOptionPane.showMessageDialog(null,"¡Gracias por su compra, vuelva pronto. ¡WE LOVE YOU!");
                            }
                            }
                        if (elec311==2){
                            JOptionPane.showMessageDialog(null,"Si desea consultar otras opciones, inicie el programa nuevamente, gracias.");
                        }
        }
}                          
}
}
    
        
             
