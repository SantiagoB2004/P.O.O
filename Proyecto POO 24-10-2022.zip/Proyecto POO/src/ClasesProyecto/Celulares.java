package ClasesProyecto;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class Celulares {
    private String referencia;
    private String color;
    private String marca;
    private String memoria;
    private String pixelesFrontal;
    private String pixelesTrasera;

    public Celulares(String referencia, String color, String marca, String memoria, String pixelesFrontal, String pixelesTrasera) {
        this.referencia = referencia;
        this.color = color;
        this.marca = marca;
        this.memoria = memoria;
        this.pixelesFrontal = pixelesFrontal;
        this.pixelesTrasera = pixelesTrasera;
    }

    public String getReferencia() {
        return referencia;
    }

    public String getColor() {
        return color;
    }

    public String getMarca() {
        return marca;
    }

    public String getMemoria() {
        return memoria;
    }

    public String getPixelesFrontal() {
        return pixelesFrontal;
    }

    public String getPixelesTrasera() {
        return pixelesTrasera;
    } 
}
