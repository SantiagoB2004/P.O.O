package ClasesProyecto;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class Computadores {

    private String referencia;
    private String marca;
    private String color;
    private String tarjetaGrafica;
    private String pulgadas;
    private String ram;

    public Computadores(String referencia, String marca, String color, String tarjetaGrafica, String pulgadas, String ram) {
        this.referencia = referencia;
        this.marca = marca;
        this.color = color;
        this.tarjetaGrafica = tarjetaGrafica;
        this.pulgadas = pulgadas;
        this.ram = ram;
    }

    public String getReferencia() {
        return referencia;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getTarjetaGrafica() {
        return tarjetaGrafica;
    }

    public String getPulgadas() {
        return pulgadas;
    }

    public String getRam() {
        return ram;
    }
}