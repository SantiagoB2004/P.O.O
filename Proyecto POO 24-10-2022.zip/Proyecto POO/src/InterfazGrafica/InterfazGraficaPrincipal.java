/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InterfazGrafica;

/**
 *
 * @author 123
 */
public class InterfazGraficaPrincipal {
    
    public static void main(String[] args) {
        // TODO code application logic here
        MenuUsuario objetoMenuUsuario = new MenuUsuario () ;
        objetoMenuUsuario.setVisible(true);
    }     
}
